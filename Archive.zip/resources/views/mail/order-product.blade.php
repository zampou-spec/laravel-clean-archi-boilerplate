<div>
  <h1>NOUVELLE COMMANDE</h1>
  <h3 style="margin-bottom: 10px;">Information du client: </h3>
  <div style="margin-left: 20px;">
    Nom complet: {{ $order['name'] }} <br />
    Pays: {{ $order['country'] }} <br />
    Numéro de téléphone: {{ $order['mobile_number'] }} <br /><br />
  </div>

  <h3 style="margin-bottom: 10px;">Produit: </h3>
  <div style="margin-left: 20px;">
    Nom: {{ $order['product']['name'] }} <br />
    Prix: {{ $order['product']['price'] }} <br />
  </div>
</div>