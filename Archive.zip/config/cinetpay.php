<?php

return [
    'CINETPAY_API_KEY' => env('CINETPAY_API_KEY', null),
    'CINETPAY_SITE_ID' =>  env('CINETPAY_SITE_ID', null)
];